from datetime import datetime, timezone
import logging
from typing import Callable
from fxserverclientpython import (
    LoginRequest,
    AddOrderRequest,
    ClientConfig,
    FxServerClientLib,
)
import asyncio
import os, json
import argparse
from fxserverclientpython.entities import (
    AccountBalance,
    AccountBalanceUpdateEvent,
    AddDealRequest,
    CancelOrderRequest,
    ChangePasswordRequest,
    ConnectionEvent,
    ContractSettingEvent,
    ContractSubsUpdateEvent,
    EditDealOCOPairRequest,
    EditOrderRequest,
    GoodTill,
    LiquidateAllRequest,
    LiquidateRequest,
    LiquidationUpdateEvent,
    LoginEvent,
    LogoutEvent,
    OpenPosition,
    OrderStatusUpdate,
    OrderUpdateEvent,
    PositionUpdateEvent,
    PriceEvent,
    PriceSnapshotRequest,
    SearchContractRequest,
    ServerEvent,
    ServerEventBase,
    SystemMessageEvent,
    WatchListUpdateEvent,
)

# Configure logging for the library
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


def handle_all_events(event: ServerEvent):
    print(f"Received event of type: {event.type}")

    # Handle each type of event
    if event.type == "AccountBalanceUpdateEvent":
        handle_account_balance_update(event)
    elif event.type == "PositionUpdateEvent":
        handle_position_update(event)
    elif event.type == "ContractSettingEvent":
        handle_contract_setting(event)
    elif event.type == "OrderUpdateEvent":
        handle_order_update(event)
    elif event.type == "LiquidationUpdateEvent":
        handle_liquidation_update(event)
    elif event.type == "LoginEvent":
        handle_login(event)
    elif event.type == "LogoutEvent":
        handle_logout(event)
    elif event.type == "ServerEvent":
        handle_server_event(event)
    elif event.type == "SystemMessageEvent":
        handle_system_message(event)
    elif event.type == "WatchListUpdateEvent":
        handle_watchlist_update(event)
    elif event.type == "ContractSubsUpdateEvent":
        handle_contract_subs_update(event)
    elif event.type == "ConnectionEvent":
        handle_connection_event(event)
    else:
        print(f"Unknown event type: {event.type}")


# Individual handlers for each event type
def handle_account_balance_update(event: AccountBalanceUpdateEvent):
    print("Account balance has been updated")


def handle_position_update(event: PositionUpdateEvent):
    print(f"Position updated for orders: {event.order_nos}")


def handle_contract_setting(event: ContractSettingEvent):
    print(f"Contract settings updated for: {event.contract_codes}")


def handle_order_update(event: OrderUpdateEvent):
    print(f"Orders updated: {event.order_nos}")


def handle_liquidation_update(event: LiquidationUpdateEvent):
    print("Liquidation update received")


def handle_login(event: LoginEvent):
    print("User logged in")


def handle_logout(event: LogoutEvent):
    print("User logged out")


def handle_server_event(event: ServerEventBase):
    print("General server event received")


def handle_system_message(event: SystemMessageEvent):
    print(f"System message: [{event.message_code}] {event.message_text}")


def handle_watchlist_update(event: WatchListUpdateEvent):
    print("Watchlist has been updated")


def handle_contract_subs_update(event: ContractSubsUpdateEvent):
    print(
        f"Contract subscriptions updated. FX Server completed: {event.fx_server_subs_completed}, "
        f"Price Agent completed: {event.price_agent_subs_completed}, "
        f"Contracts: {event.contract_subs}"
    )


def handle_connection_event(event: ConnectionEvent):
    print(
        f"Connection status changed - FX Server: {event.fx_server_connected}, "
        f"Price Agent: {event.price_agent_connected}"
    )


async def test_login(is_interactive: bool | None):

    loop = asyncio.get_running_loop()

    fxserver_client_lib = FxServerClientLib(loop)

    user_config_dict = {
        "endpoint" : "<FXSERVER_WEBSOCKET>",
        "price_agent_endpoint" : "<PRICE_AGENT_WEBSOCKET>",
        "trade_key" : "<TRADE_KEY>",
        "webproxy_endpoint" : "<WEB_PROXY_ENDPOINT>",
        "username" : "<USERNAME>",
        "valid_generated_token" : "<VALID_GENERATED_TOKEN>"
    }

    fxserver_client_lib.init(user_config_dict)

    try:
        login_reply = await fxserver_client_lib.login()
    except Exception as e:
        print("login fail with error:")
        print(e)
        exit(1)

    if is_interactive:
        print(
            "Login success. Interactive mode enabled. Type 'exit' or 'logout' to quit."
        )
        while True:
            user_input = await loop.run_in_executor(None, lambda: input("Enter: "))
            # clean the previous output, tested
            if user_input.lower().startswith("login reply"):
                print(f"{login_reply}")
            elif user_input.lower().startswith("clear"):
                os.system("cls")
            # logout, tested
            elif user_input.lower().startswith("exit") or user_input.lower().startswith(
                "logout"
            ):
                try:
                    await fxserver_client_lib.logout()
                    print("Logout and Exiting...")
                except Exception as e:
                    print(f"Error in logout: {e}")
                break
            # get_account_info, tested
            elif user_input.lower().startswith("account"):
                try:
                    acc_info = fxserver_client_lib.get_account_info()
                    print(f"acc info: {acc_info}")
                except Exception as e:
                    print(f"Error in get_account_info: {e}")
            # get_account_balance, tested
            elif user_input.lower().startswith("balance"):
                try:
                    acc_balance = fxserver_client_lib.get_account_balance()
                    print(f"balance: {acc_balance}")
                except Exception as e:
                    print(f"Error in get_account_balance: {e}")
            # get_contract_setting, tested
            elif user_input.lower().startswith("contracts"):
                try:
                    contracts = fxserver_client_lib.get_contract_setting()
                    print(f"contracts: {contracts}")
                except Exception as e:
                    print(f"Error in get_contract_setting: {e}")
            # get_price_info, tested
            elif user_input.lower().startswith("price"):
                parts = user_input.split(" ", 2)
                if len(parts) == 2:
                    symbol = parts[1]
                else:
                    print("Provide a symbolname with space. i.e: price XAUUSD")
                    continue
                try:
                    price = fxserver_client_lib.get_price_info(symbol)
                    print(f"{symbol}: {price}")
                except Exception as e:
                    print(f"Error in get_price_info: {e}")
            # add_order
            elif user_input.lower().startswith("order"):
                parts = user_input.split(" ")
                order_request: AddOrderRequest = AddOrderRequest(
                    contract_code="",
                    price=0,
                    buy_or_sell=False,
                    amount=0,
                    good_till=GoodTill.GOOD_TILL_CANCEL,
                    limit_or_stop=False,
                    take_profit_present=True,
                    take_profit_price=1.13000,
                    take_profit_good_till=GoodTill.GOOD_TILL_CANCEL,
                    trailing_stop_size=1,
                    stop_loss_present=True,
                    stop_loss_price=1.11500,
                    stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL,
                )
                if len(parts) == 2 and parts[1] == "default":
                    print("Submitting GBPNZD order with default values")
                    order_request.contract_code = "GBPNZD"
                    order_request.price = 2.26135
                    order_request.buy_or_sell = False
                    order_request.amount = 100000.0
                    order_request.is_close = None
                    order_request.good_till = GoodTill.GOOD_TILL_CANCEL
                    order_request.ref_order = None
                    order_request.comment = ""
                    order_request.limit_or_stop = False

                try:
                    order_res = await fxserver_client_lib.add_order(order_request)
                    print(f"Order result: {order_res}")
                except Exception as e:
                    print(f"Error in add_order: {fxserver_client_lib.handle_exception_response(e)}")
            # edit_order
            elif user_input.lower().startswith("edit order"):
                order_request: EditOrderRequest = EditOrderRequest(
                    order_no="3854",
                    price=2.30,
                    amount=150000,
                    good_till=GoodTill.GOOD_TILL_DAY_END,
                    comment=None,
                    take_profit_present=True,
                    take_profit_price=1.13000,
                    take_profit_good_till=GoodTill.GOOD_TILL_CANCEL,
                    trailing_stop_size=1,
                    stop_loss_present=True,
                    stop_loss_price=1.11500,
                    stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL,
                )

                try:
                    order_res = await fxserver_client_lib.edit_order(order_request)
                    print(f"Order result: {order_res}")
                except Exception as e:
                    print(f"Error in edit_order: {fxserver_client_lib.handle_exception_response(e)}")
            # cancel_order, tested. Will crash when the order does not exist
            elif user_input.lower().startswith("cancel order"):
                order_request: CancelOrderRequest = CancelOrderRequest(
                    order_no="3864", comment="test"
                )
                try:
                    await fxserver_client_lib.cancel_order(order_request)
                    print("Order cancelled successfully.")
                except Exception as e:
                    print(f"Error in cancel_order: {fxserver_client_lib.handle_exception_response(e)}")
            # add_deal
            elif user_input.lower().startswith("add deal"):
                deal_request: AddDealRequest = AddDealRequest(
                    contract_code="GBPNZD",
                    price=None,
                    buy_or_sell=True,
                    accept_pips=0,
                    amount=100000,
                    comment="",
                    price_tag=None,
                    take_profit_present=True,
                    take_profit_price=1.13000,
                    take_profit_good_till=GoodTill.GOOD_TILL_CANCEL,
                    trailing_stop_size=1,
                    stop_loss_present=True,
                    stop_loss_price=1.11500,
                    stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL,
                )
                try:
                    deal_res = await fxserver_client_lib.add_deal(deal_request)
                    print(f"deal result: {deal_res}")
                except Exception as e:
                    print(f"Error in add_deal: {fxserver_client_lib.handle_exception_response(e)}")
            # edit_deal_oco_pair, edit order can do this job already...
            elif user_input.lower().startswith("edit_deal_oco_pair"):
                edit_deal_request: EditDealOCOPairRequest = EditDealOCOPairRequest(
                    order_no="3865",
                    take_profit_present=True,
                    take_profit_price=0.83,
                    take_profit_good_till=GoodTill.GOOD_TILL_CANCEL,
                    trailing_stop_size=1,
                    stop_loss_present=True,
                    stop_loss_price=0.86,
                    stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL,
                )
                try:
                    edit_deal_res = await fxserver_client_lib.edit_deal_oco_pair(
                        edit_deal_request
                    )
                    print(f"edit deal result: {edit_deal_res}")
                except Exception as e:
                    print(f"Error in edit_deal_oco_pair: {fxserver_client_lib.handle_exception_response(e)}")
            # liqudate all, tested (manual update does not work at the present)
            elif user_input.lower().startswith("liquidate"):
                liquidate_request = LiquidateRequest(
                    order_no="183835",
                    accept_pips=1,
                    price=None,
                    price_tag=None,
                    amount=100000,
                )
                try:
                    liquidate_res = await fxserver_client_lib.liquidate(
                        liquidate_request
                    )
                    print(f"liquidate result: {liquidate_res}")
                except Exception as e:
                    print(f"Error in liquidate: {fxserver_client_lib.handle_exception_response(e)}")
            # liqudate all, tested (manual update does not work at the present)
            elif user_input.lower().startswith("all_liquidate"):
                liquidate_all_request = LiquidateAllRequest(
                    accept_pips=1,
                    amount=None,
                    price=None,
                    price_tag=None,
                    liq_refs=[{"orderNo": 15 ,"amount": 100}, {"orderNo": 53 ,"amount": 100000}],
                    contract_code=None,
                    buy_or_sell=None,
                )
                try:
                    liquidate_all_res = await fxserver_client_lib.liquidate_all(
                        liquidate_all_request
                    )
                    print(f"liquidate all result: {liquidate_all_res}")
                except Exception as e:
                    print(f"Error in liquidate_all: {fxserver_client_lib.handle_exception_response(e)}")
            # get_pending_orders, tested
            elif user_input.lower().startswith("pending order"):
                try:
                    pending_orders = fxserver_client_lib.get_pending_orders()
                    for order in pending_orders:
                        print(f"pending order: {order}")
                except Exception as e:
                    print(f"Error in get_pending_orders: {e}")
            # get_executed_orders_today, tested
            elif user_input.lower().startswith("today executed order"):
                try:
                    executed_orders = fxserver_client_lib.get_executed_orders_today()
                    print(f"executed orders: {executed_orders}")
                except Exception as e:
                    print(f"Error in get_executed_orders_today: {e}")
            # get_cancelled_orders_today, tested
            elif user_input.lower().startswith("today cancelled order"):
                try:
                    cancelled_orders = fxserver_client_lib.get_cancelled_orders_today()
                    print(f"cancelled orders: {cancelled_orders}")
                except Exception as e:
                    print(f"Error in get_cancelled_orders_today: {e}")
            # get_liquidations, tested
            elif user_input.lower().startswith("get liquidations"):
                try:
                    liquidations = fxserver_client_lib.get_liquidations()
                    print(f"liquidations: {liquidations}")
                except Exception as e:
                    print(f"Error in get_liquidations: {e}")

            # TODO: Confirm whether the empty dict is correct
            # get_executed_order_for_positions, return empty dict???
            elif user_input.lower().startswith("get executed order for positions"):
                try:
                    executed_orders = (
                        fxserver_client_lib.get_executed_order_for_positions()
                    )
                    print(f"executed orders: {executed_orders}")
                except Exception as e:
                    print(f"Error in get_executed_order_for_positions: {e}")

            # TODO: Confirm whether the empty dict is correct
            # get_position_for_executed_orders, return empty dict???
            elif user_input.lower().startswith("get position for executed orders"):
                try:
                    positions = fxserver_client_lib.get_position_for_executed_orders()
                    print(f"positions: {positions}")
                except Exception as e:
                    print(f"Error in get_position_for_executed_orders: {e}")

            # get_order_info, tested
            elif user_input.lower().startswith("get order info"):
                order_id = input("Enter order id: ")
                try:
                    order_info = fxserver_client_lib.get_order_info(order_id)
                    print(f"order info: {order_info}")
                except Exception as e:
                    print(f"Error in get_order_info: {e}")
            # get_executed_order_history, tested
            elif user_input.lower().startswith("get executed order history"):
                try:
                    history = await fxserver_client_lib.get_executed_order_history(
                        fromDate="2025-03-01", toDate="2025-03-31"
                    )
                    print(f"Executed order history: {history}")
                except Exception as e:
                    print(f"Error in get_executed_order_history: {e}")
            # get_cancelled_order_history, tested
            elif user_input.lower().startswith("get cancelled order history"):
                try:
                    history = await fxserver_client_lib.get_cancelled_order_history(
                        fromDate="2025-03-01", toDate="2025-03-31"
                    )
                    print(f"cancelled order history: {history}")
                except Exception as e:
                    print(f"Error in get_cancelled_order_history: {e}")
            # get_liquidation_history, tested
            elif user_input.lower().startswith("get liquidation history"):
                try:
                    history = await fxserver_client_lib.get_liquidation_history(
                        fromDate="2025-03-01", toDate="2025-03-31"
                    )
                    print(f"liquidation history: {history}")
                except Exception as e:
                    print(f"Error in get_liquidation_history: {e}")

            # TODO: Find a way to verify the result
            # calc_Profit
            elif user_input.lower().startswith("calc profit"):
                openPos = OpenPosition(
                    order_no="",
                    contract_code="",
                    buy_or_sell=True,
                    amount=0,
                    exec_price=0,
                    take_profit_price=0,
                    take_profit_good_till=None,
                    take_profit_good_till_date=None,
                    stop_loss_price=0,
                    stop_loss_good_till=None,
                    stop_loss_good_till_date=None,
                    executed_time=datetime.now(timezone.utc),
                    floating=0,
                    revalue_rate=0,
                    commission=0,
                )
                try:
                    res = fxserver_client_lib.calc_Profit(openPos)
                    print(f"position profit: {res}")
                except Exception as e:
                    print(f"Error in calc profit: {e}")

            # TODO: Find a way to verify the result
            # calc_account_profit, may be need to get account summary... (At least it does not crash)
            elif user_input.lower().startswith("calc account profit"):
                accountBal = AccountBalance(
                    settle_currency="",
                    display_currency="",
                    fixed_settlement_ex_rate=0,
                    credit_limit=0,
                    free_margin=0,
                    balance=0,
                    equity=0,
                    day_pnl=0,
                    floating_pnl=0,
                    margin_ratio=0,
                    margin_alert_ratio=0,
                    margin_call_ratio=0,
                    margin_cut_ratio=0,
                    margin_state=0,
                )
                try:
                    result = fxserver_client_lib.calc_account_profit(accountBal)
                    print(f"Account profit: {result}")
                except Exception as e:
                    print(f"Error in calc account profit: {e}")

            # add_price_listener, tested
            elif user_input.lower().startswith("add price listener"):
                try:
                    callbackId = fxserver_client_lib.add_price_listener(
                        lambda event: {
                            # print(f"Price event received: {event}")
                        }
                    )
                    print(f"Added listening. Price listener callbackId: {callbackId}")
                except Exception as e:
                    print(f"Error in add_price_listener: {e}")
            # remove_price_listener, tested
            elif user_input.lower().startswith("remove_price_listener"):
                callbackId = user_input.split(" ")[1]
                try:
                    fxserver_client_lib.remove_price_listener(callbackId)
                    print("Removed Price listening.")
                except Exception as e:
                    print(f"Error in remove_price_listener: {e}")
            # add_event_listener, tested
            elif user_input.lower().startswith("add event listener"):
                try:
                    callback_id = fxserver_client_lib.add_event_listener(
                        handle_all_events
                    )
                    print(
                        f"Added event listening. Event listener callbackId: {callback_id}"
                    )
                except Exception as e:
                    print(f"Error in add_event_listener: {e}")
            # remove_event_listener, tested
            elif user_input.lower().startswith("remove_event_listener"):
                callbackId = user_input.split(" ")[1]
                try:
                    fxserver_client_lib.remove_event_listener(callbackId)
                    print("Removed event listening.")
                except Exception as e:
                    print(f"Error in remove_event_listener: {e}")
            # change_password, tested
            elif user_input.lower().startswith("change password"):
                oldPas = input("Existing password: ")
                new_password = input("New password: ")
                changePasReq = ChangePasswordRequest(
                    old_password=oldPas, new_password=new_password
                )
                try:
                    request_res = await fxserver_client_lib.change_password(
                        changePasReq
                    )
                    print(f"Password changed successfully. {request_res}")
                except Exception as e:
                    print(f"Error in change_password: {e}")
            # get_open_positions, tested
            elif user_input.lower().startswith("get open positions"):
                try:
                    positions = fxserver_client_lib.get_open_positions()
                    print(f"positions: {positions}")
                except Exception as e:
                    print(f"Error in get_open_positions: {e}")
            else:
                print("Invalid command")
    else:
        print(f"login success: {login_reply}")

        acc_info = fxserver_client_lib.get_account_info()
        print(f"acc info: {acc_info}")

        open_pos = fxserver_client_lib.get_open_positions()
        print(f"open pos: {open_pos}")

        acc_balance = fxserver_client_lib.get_account_balance()
        print(f"balance: {acc_balance}")

        contracts = fxserver_client_lib.get_contract_setting()
        # print(f"contracts: {contracts}")

        price = fxserver_client_lib.get_price_info("XAUUSD")
        print(f"XAUUSD: {price}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command",
        choices=["login"],
        help="""
                        buildjs: build the js code and copy to target directory
                        login: test login using your config
                        """,
    )
    parser.add_argument(
        "-i", "--interact", help="Interactive mode", action="store_true", default=None
    )

    args = parser.parse_args()

    if args.command == "login":
        asyncio.run(test_login(args.interact))


if __name__ == "__main__":
    main()
