# Environment Setup (With Poetry)

You may want to use Poetry to install dependencies for you. In this case, you are required to use Poetry 2+, as well as python 3.12.

1. Please read the official (Python documentation)[https://docs.python.org/3/] for more information on how to install Python.

2. Please read the official (Poetry documentation)[https://python-poetry.org/docs/] for more information on how to install Poetry.

3. Then install python packages with: `poetry install`

4. Then run the program with: `poetry run python main.py`, while main.py being your implementation on using this python library

# Environment Setup (Without Poetry)

If you do not want to use Poetry, you can install those dependencies with pip. You are required to use python 3.12.

1. Please read the official (Python documentation)[https://docs.python.org/3/] for more information on how to install Python.

2. Then install python packages with:

```powershell
pip install "quickjs>=1.19.4,<2.0.0" "pydantic>=2.10.6,<3.0.0" "websockets>=15.0.1,<16.0.0" "requests>=2.32.3,<3.0.0" "getmac>=0.9.5,<0.10.0"
```

3. Then run the program with: `python main.py`, while main.py being your implementation on using this python library

---

# Quick Start

```python
from fxserverclientpython import (
    FxServerClientLib,
)
import asyncio

async def main():
    loop = asyncio.get_running_loop()
    fxserver_client_lib = FxServerClientLib(loop)

    user_config_dict = {
        "endpoint": "<FXSERVER_WEBSOCKET>",
        "price_agent_endpoint": "<PRICE_AGENT_WEBSOCKET>",
        "trade_key": "<TRADE_KEY>",
        "webproxy_endpoint": "<WEB_PROXY_ENDPOINT>",
        "username": "<USERNAME>",
        "valid_generated_token": "<VALID_GENERATED_TOKEN>"
    }
    fxserver_client_lib.init(user_config_dict)
    try:
        login_reply = await fxserver_client_lib.login()
        print("Login response:", login_reply)
    except Exception as e:
        print("Login failed with error:")
        print(e)
        exit(1)

if __name__ == "__main__":
    asyncio.run(main())
```

### Explanation for the parameters:

`endpoint`: FxServer Connection websocket URL, which should start with wss:// and present on API Management Page as `FXSERVER_WEBSOCKET`

`price_agent_endpoint`: Price Agent Connection websocket URL, which should start with wss:// and present on API Management Page as `PRICE_AGENT_WEBSOCKET`

`trade_key`: Trade permission key for FxServer, which should present on API Management Page as `TRADE_KEY`

`webproxy_endpoint`: Web Proxy RESTful API Url, which should start with https:// and present on API Management Page as `WEB_PROXY_ENDPOINT`

`username`: Login user ID

`valid_generated_token`: Valid generated token for the account, which should present on API Management Page as `VALID_GENERATED_TOKEN`

### From the example code

#### When Login success

`login_reply` object will hold a reference to the `LoginReply` Python object when success. Please take reference to `LoginReply` object in `entities.py` for more details.

#### When Login failed

You will be encountered with an exception with similar json string:

```json
{

"message":"{\"serviceType\":1,\"functionType\":1,\"body\":{\"accountID\":\"\",\"uid\":\"8751\",\"fail\":\"Invalid Password\",\"stat\":\"fail\",\"myid\":\"roont\",\"msgcd1\":\"303\"}
}

```

### The Provided `main.py`

The `main.py` is the implementation example of using this python library, which can be used as a reference for implementation.
You could use the following command to perform interactive login for development:

```
poetry run python .\src\main.py login --interact
```

---

# Functions supported

It is advised to use try catch on implementation of python logic and log for exception study. When the action or request failed (i.e failed to submit order or deal), it will raise exception directly, even if the request is valid.

All examples functions other than `Logins` has presumed the action has passed the login stage.

## Table of Contents

- [Logout](#logout)
- [Get account info](#get-account-info)
- [Get account balance](#get-account-balance)
- [Get contract setting](#get-contract-setting)
- [Get latest price](#get-latest-price-info-for-certain-contract)
- [Add Order](#add-order)
- [Edit Order](#edit-order)
- [Cancel Order](#cancel-order)
- [Add deal](#add-deal)
- [Edit OCO deal pair](#edit-oco-deal-pair)
- [Liquidation](#liquidation)
- [Liquidate All](#liquidate-all)
- [Get Pending Order](#get-pending-order)
- [Get Today executed order](#get-today-executed-order)
- [Get Today cancelled order](#get-today-cancelled-order)
- [Get Executed order for positions](#get-executed-order-for-positions)
- [Get Position for executed order](#get-position-for-executed-order)
- [Get Order Info](#get-order-info)
- [Get Execute order history](#get-execute-order-history)
- [Get Cancelled order history](#get-cancelled-order-history)
- [Get Liquidation history (Duration)](#get-liquidation-history-duration)
- [Get Liquidation history (All)](#get-liquidation-history-all)
- [Calculate Position Profit](#calculate-position-profit)
- [Calculate account profit](#calculate-account-profit)
- [Add price listener callback](#add-price-listener-callback)
- [Remove price listener callback](#remove-price-listener-callback)
- [Add Event listener callback](#add-event-listener-callback)
- [Remove Event listener callback](#remove-event-listener-callback)
- [Change password](#change-password)
- [Get Open Positions](#get-open-positions)

## Login

After setting up the config.json, you can use the login function to connect to the FxServer. This step should be performed before any order or deal action. The follow code supports logging in with web proxy and direct connection method.

##### Example

```python

loop = asyncio.get_running_loop()
fxserver_client_lib = FxServerClientLib(loop)
with open(config_path) as f:
        config_dict = json.load(f)
setup_details = config_dict["setup"]
client_config = ClientConfigV2.model_validate(setup_details)
fxserver_client_lib.init(client_config)
# Login with token
login_request = fxserver_client_lib.constructLoginRequestWithToken(client_config, config_dict)
login_reply = await fxserver_client_lib.login(login_request)
```

##### When success

`login_reply` object will hold a reference to the `LoginReply` Python object when success. Please take reference to `LoginReply` object in `entities.py` for more details.

##### When failed

You will be encountered with an exception with similar json string:

```json
{

"message":"{\"serviceType\":1,\"functionType\":1,\"body\":{\"accountID\":\"\",\"uid\":\"8751\",\"fail\":\"Invalid Password\",\"stat\":\"fail\",\"myid\":\"xxxxx\",\"msgcd1\":\"303\"}
}

```

## Logout

Perform logout and disconnect from the FxServer.

```python
await fxserver_client_lib.logout()
```

##### When Success

No output will be provided

##### When failed

Exception occurred. The exception message should contain reason of failure and error code.

## Get account info

Obtain account basic info from FxServer

```python
acc_info  =  fxserver_client_lib.get_account_info()
```

##### When success

`acc_info` object will hold a reference to the `AccountInfo` Python object when success. Please take reference to `AccountInfo` python object in `entities.py` for more details.

The `acc_info` object will not be None.

##### When failed

Exception occurred. The exception message should contain reason of failure and error code.

## Get account balance

Obtain accoutn balance information from FxServer

```python
acc_balance  =  fxserver_client_lib.get_account_balance()
```

##### When success

`acc_balance` object will hold a reference to the `AccountBalance` Python object when success. Please take reference to `AccountBalance` python object in `entities.py` for more details.

The `acc_balance` object will not be None.

##### When failed

Exception occurred. The Exception will contain reason of failure and error code.

## Get contract setting

Obtain all contract setting related to current login account

```ptyhon
contracts = fxserver_client_lib.get_contract_setting()
```

##### When success

contracts object will hold a reference to the `ContractSetting` Python object when success. Please take reference to `ContractSetting` python object in `entities.py` for more details.

The `ContractSetting` object will not be None.

##### When failed

Exception occurred. The Exception will contain reason of failure and error code.

## Get latest price info for certain contract

```python
#symbol will be the contract name
price = fxserver_client_lib.get_price_info(symbol)
```

##### When success

`price` object will hold a reference to the `PriceInfo` Python object when success. Please take reference to `PriceInfo` python object in `entities.py` for more details.

The value in `price` (i.e bid and ask) has already applied the account's contract setting (bid and ask adjustment).

If such contract do not exist, price will be `None`

##### When failed

Exception occurred.

## Add order

Add pending order to FxServer.

```python
# Construct the request object
order_request = AddOrderRequest(
                    contract_code="",
                    price=0,
                    buy_or_sell=False,          # true: buy, false: sell
                    amount=0,
                    is_close=None,
                    good_till=GoodTill.GOOD_TILL_CANCEL,
                    ref_order=None,
                    comment="",
                    limit_or_stop=False,
                    take_profit_present=False,
                    take_profit_price=None,
                    take_profit_good_till=None,
                    trailing_stop_size=None,
                    stop_loss_present=None,
                    stop_loss_price=None,
                    stop_loss_good_till=None,
                    manual_update=None,
                )

# Further define the order_request details
order_request.contract_code = "GBPNZD"
order_request.price = 2.26135
order_request.buy_or_sell = False
order_request.amount = 100000.0
order_request.good_till = GoodTill.GOOD_TILL_CANCEL
order_request.limit_or_stop = False

# TP/SL function will be disabled by default
# If you would like to enable TP function, please set take_profit_present to True
# take_profit_price, take_profit_good_till and trailing_stop_size only take effect when take_profit_present is set to True
order_request.take_profit_present=True
order_request.take_profit_price=1.13000
order_request.take_profit_good_till=GoodTill.GOOD_TILL_CANCEL
order_request.trailing_stop_size=50

# Similar to TP, SL function will be disabled by default
# If you would like to enable SL function, please set stop_loss_present to True
# stop_loss_price and stop_loss_good_till will only take effect when stop_loss_present is set to True
order_request.stop_loss_present=True
order_request.stop_loss_price=1.11500
order_request.stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL

order_res = await fxserver_client_lib.add_order(order_request)
```

##### When success

`order_res` object will hold a reference to the `AddOrderRequestReply` Python object when success. Please take reference to `AddOrderRequestReply` python object in `entities.py` for more details.

##### When failed (Failed to place order)

Exception occurred. The exception message should contain error code from FxServer.
If you want to get the corresponding error message that the error code represented, you can use the `handle_exception_response` method of `fxserver_client_lib` object.

## Edit order

Edit any pending order that submitted to FxServer.

```python
# Construct the request object
order_request = EditOrderRequest(
                    order_no="",
                    price=0,
                    amount=0,
                    good_till=GoodTill.GOOD_TILL_DAY_END,
                    comment=None,
                    take_profit_present=False,
                    take_profit_price=0,
                    take_profit_good_till=GoodTill.GOOD_TILL_CANCEL,
                    trailing_stop_size=0,
                    stop_loss_present=False,
                    stop_loss_price=0,
                    stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL,
                    manual_update = None
                )

# Further define the value.
order_request.order_no="3854"
order_request.price=2.30
order_request.amount=150000
order_request.good_till=GoodTill.GOOD_TILL_DAY_END
order_request.comment=None

# Since the constructor will disable the TP/SL by default. Please be extra careful with the following setting.
# If the order enabled TP/SL when adding and you would like to keep those, the following value should be the same those during order adding
# Otherwise it will be overriding the existing TP/SL setting.
order_request.take_profit_present=True
order_request.take_profit_price=1.13000
order_request.take_profit_good_till=GoodTill.GOOD_TILL_CANCEL
order_request.trailing_stop_size=50
order_request.stop_loss_present=True
order_request.stop_loss_price=1.11500
order_request.stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL
order_request.manual_update = None
order_res = await fxserver_client_lib.edit_order(order_request)
```

##### When success

`order_res` object will hold a reference to the `EditOrderRequestReply` Python object when success. Please take reference to `EditOrderRequestReply` python object in `entities.py` for more details.

##### When failed (Failed to edit order)

Exception occurred. The exception message should contain error code from FxServer.
If you want to get the corresponding error message that the error code represented, you can use the `handle_exception_response` method of `fxserver_client_lib` object.

## Cancel order

Cancel any pending order that submitted to FxServer

```python
# Construct the request object
order_request = CancelOrderRequest(
                    order_no="",
                    comment=""
                )

# Further define the value.
order_request.order_no="3864",
order_request.comment="test"

# Send the request to FxServer
await fxserver_client_lib.cancel_order(order_request)
```

##### When success

An empty object will be returned when success. Please check the empty object to verify if the request is successful.

##### When failed (Failed to cancel order)

Exception occurred. The exception message should contain error code from FxServer.
If you want to get the corresponding error message that the error code represented, you can use the `handle_exception_response` method of `fxserver_client_lib` object.

## Add deal

Add a deal to FxServer.

```python
# Construct the request object
deal_request = AddDealRequest(
                    contract_code="",
                    price=None,
                    buy_or_sell=True,         # true: buy, false: sell
                    accept_pips=0,
                    amount=0,
                    comment="",
                    price_tag=None,
                    take_profit_present=False,
                    take_profit_price=None,
                    take_profit_good_till=None,
                    trailing_stop_size=None,
                    stop_loss_present=False,
                    stop_loss_price=None,
                    stop_loss_good_till=None,
                    manual_update = None
                )

# Further define the value.
deal_request.contract_code="GBPNZD"
deal_request.price=1.12500
deal_request.buy_or_sell=True
deal_request.accept_pips=0
deal_request.amount=100000
deal_request.comment="test"

# price_tag is used to specify the type of price.
# If you do not specify the price_tag, the system will use the current market price as the price.
deal_request.price_tag=None

# TP function will be disabled by default.
# You are required to set it to True to enable it.
# take_profit_price, take_profit_good_till and trailing_stop_size will only take effect when take_profit_present is set to True
deal_request.take_profit_present=True
deal_request.take_profit_price=1.13000
deal_request.take_profit_good_till=GoodTill.GOOD_TILL_CANCEL
deal_request.trailing_stop_size=1

# Similar to TP, SL function will be disabled by default.
# You are required to set it to True to enable it.
# stop_loss_price and stop_loss_good_till will only take effect when stop_loss_present is set to True
deal_request.stop_loss_present=True
deal_request.stop_loss_price=1.11500
deal_request.stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL

# Send the request to FxServer
deal_res = await fxserver_client_lib.add_deal(deal_request)
```

##### When success

`deal_res` object will hold a reference to the `AddDealRequestReply` Python object when success. Please take reference to `AddDealRequestReply` python object in `entities.py` for more details.

##### When failed (Failed to add deal)

Exception occurred. The exception message should contain error code from FxServer.
If you want to get the corresponding error message that the error code represented, you can use the `handle_exception_response` method of `fxserver_client_lib` object.

##### Caveat

If you would like to edit an existing deal, please use the function `edit_order()` function instead. `edit_deal_oco_pair()` is only used to edit TP/SL for the deal and it does not support editing other fields inside th deal.

## Edit OCO deal pair

Editing an existing deal in FxServer.

```python
# Construct the request object
edit_deal_request = EditDealOCOPairRequest(
                    order_no="",
                    take_profit_present=None,
                    take_profit_price=None,
                    take_profit_good_till=None,
                    trailing_stop_size=None,
                    stop_loss_present=None,
                    stop_loss_price=None,
                    stop_loss_good_till=None,
                    manual_update = None,
                )

# Since the constructor will disable the TP/SL by default. Please be extra careful with the following setting.
# If the order enabled TP/SL when adding and you would like to keep those, the following value should be the same those during order adding
# Otherwise it will be overriding the existing TP/SL setting.
edit_deal_request.order_no="3865"
edit_deal_request.take_profit_present=True
edit_deal_request.take_profit_price=1.13000
edit_deal_request.take_profit_good_till=GoodTill.GOOD_TILL_CANCEL
edit_deal_request.trailing_stop_size=1
edit_deal_request.stop_loss_present=True
edit_deal_request.stop_loss_price=1.11500
edit_deal_request.stop_loss_good_till=GoodTill.GOOD_TILL_CANCEL

# Send the request to FxServer
await fxserver_client_lib.edit_deal(edit_deal_request)
```

##### When success

No return value when success

##### When failed (Failed to add deal)

Exception occurred. The exception message should contain error code from FxServer.
If you want to get the corresponding error message that the error code represented, you can use the `handle_exception_response` method of `fxserver_client_lib` object.

## Liquidation

Liquidate an existing deal.

```python
# Construct the request object
liquidate_request = LiquidateRequest(
                    order_no="",
                    accept_pips=0,
                    price=None,
                    price_tag=None,
                    amount=0,
                    manual_update=None,
                )

# If you does not specify the price and price_tag, the system will use the current market price as the liquidation price.
liquidate_request.order_no="3865"
liquidate_request.accept_pips=50
liquidate_request.amount=100000

# Send the request to FxServer
liquidate_res = await fxserver_client_lib.liquidate(liquidate_request)
```

##### When success

`liquidate_res` object will hold a reference to the `LiquidateRequestReply` Python object when success. Please take reference to `LiquidateRequestReply` python object in `entities.py` for more details.

##### When failed (Failed to liquidate deal)

Exception occurred. The exception message should contain error code from FxServer.
If you want to get the corresponding error message that the error code represented, you can use the `handle_exception_response` method of `fxserver_client_lib` object.

## Liquidate All

Liquidate all existing deals.

```python
# Construct the request object
liquidate_all_request = LiquidateAllRequest(
                    accept_pips=0,
                    amount=None,
                    price=None,
                    price_tag=None,
                    liq_refs=None,
                    contract_code=None,
                    buy_or_sell=True,                 # true: buy, false: sell
                    manual_update=None
                )

# If you does not specify the price and price_tag, the system will use the current market price as the liquidation price.
# liq_refs is a list of dictionaries. Each dictionary contains the order_no and amount of the deal to be liquidated.
liquidate_all_request.liq_refs=[{"orderNo": 15 ,"amount": 100}, {"orderNo": 53 ,"amount": 100000}],
liquidate_all_request.accept_pips=1

# Send the request to FxServer
liquidate_all_res = await fxserver_client_lib.liquidate_all(liquidate_all_request)
```

##### When success

`liquidate_all_res` object will hold a reference to the `LiquidateAllRequestReply` Python object when success. Please take reference to `LiquidateAllRequestReply` python object in `entities.py` for more details.

##### When failed (Failed to liquidate all deals)

Exception occurred. The exception message should contain error code from FxServer.
If you want to get the corresponding error message that the error code represented, you can use the `handle_exception_response` method of `fxserver_client_lib` object.

## Get Pending Order

Get all pending orders from FxServer

```python
# Send the request to FxServer
get_pending_order_res = await fxserver_client_lib.get_pending_orders()
```

##### When success

`get_pending_order_res` object will hold a reference to a list of `Order` Python object when success. Please take reference to `Order` python object in `entities.py` for more details.

`get_pending_order_res` will be empty array if the account does not have any pending orders.

##### When failed (Failed to get pending order)

Exception occurred. The exception message should contain error code from FxServer.

## Get Today executed order

Get a list of current day executed orders ID from FxServer

```python
# Send the request to FxServer
executed_orders = fxserver_client_lib.get_executed_orders_today()
```

##### When success

`executed_orders` object will hold a reference to a list of `str` Python object when success, represeting the list of ID of executed orders for today.

`executed_orders` will be empty array if the account does not have any executed orders for today.

##### When failed (Failed to get today executed order)

Exception occurred. The exception message should contain error code from FxServer.

## Get Today cancelled order

Get a list of current day cancelled orders ID from FxServer

```python
# Send the request to FxServer
cancelled_orders = fxserver_client_lib.get_cancelled_orders_today()
```

##### When success

`cancelled_orders` object will hold a reference to a list of `str` Python object when success, represeting the list of ID of cancelled orders for today.

`cancelled_orders` will be empty array if the account does not have any cancelled orders for today.

##### When failed (Failed to get today cancelled order)

Exception occurred. The exception message should contain error code from FxServer.

## Get Executed order for positions

Get a list of executed orders for positions from FxServer

```python
# Send the request to FxServer
executed_orders = (fxserver_client_lib.get_executed_order_for_positions())
```

##### When success

`executed_orders` object will hold a reference to a list of `dict[int | float, int | float]` Python object when success.

##### When failed (Failed to get executed orders for positions)

Exception occurred.

## Get Position for executed order

Get a list of position for executed order from FxServer

```python
# Send the request to FxServer
positions = fxserver_client_lib.get_position_for_executed_orders()
```

##### When success

`positions` object will hold a reference to a list of `dict[int | float, int | float]` Python object when success.

##### When failed (Failed to get position for executed order)

Exception occurred.

## Get Order Info

Get order info from FxServer

```python
# Send the request to FxServer
order_info = fxserver_client_lib.get_order_info(order_id)
```

##### When success

`order_info` object will hold a reference to a `Order` Python object when success. Please take reference to `Order` python object in `entities.py` for more details.

If the order does not exist, `order_info` will be `None`.

##### When failed (Failed to get order info)

Exception occurred.

## Get Execute order history

Get a list of executed orders from FxServer

```python
# Send the request to FxServer
history = await fxserver_client_lib.get_executed_order_history(fromDate="2025-03-01", toDate="2025-03-31")
```

##### When success

`history` object will hold a reference to a list of `Order` Python object when success. Please take reference to `Order` python object in `entities.py` for more details.

If the account does not have order history during that duration, `history` will be empty array.

##### When failed (Failed to get executed orders)

Exception occurred.

## Get Cancelled order history

Get a list of cancelled orders from FxServer

```python
# Send the request to FxServer
history = await fxserver_client_lib.get_cancelled_order_history(fromDate="2025-03-01", toDate="2025-03-31")
```

##### When success

`history` object will hold a reference to a list of `Order` Python object when success. Please take reference to `Order` python object in `entities.py` for more details.

If the account does not have cancelled order history during that duration, `history` will be empty array.

##### When failed (Failed to get cancelled orders)

Exception occurred.

## Get Liquidation history (Duration)

Get liquidation history from FxServer for a specific duration

```python
# Send the request to FxServer
history = await fxserver_client_lib.get_liquidation_history(fromDate="2025-03-01", toDate="2025-03-31")
```

##### When success

`history` object will hold a reference to a list of `Liquidation` Python object when success. Please take reference to `Liquidation` python object in `entities.py` for more details.

If the account does not have liquidation history during that duration, `history` will be empty array.

##### When failed (Failed to get liquidation history)

Exception occurred.

## Get Liquidation History (All)

Get all liquidation history from FxServer

```python
# Send the request to FxServer
liquidations = fxserver_client_lib.get_liquidations()
```

##### When success

`liquidations` object will hold a reference to a list of `Liquidation` Python object when success. Please take reference to `Liquidation` python object in `entities.py` for more details.

`liquidations` will be empty array if the account does not have any liquidation history.

##### When failed (Failed to get liquidation history)

Exception occurred.

## Calculate Position Profit

Calculate the profit of a position

```python
# Send the request to FxServer
openPos = OpenPosition(
                    order_no="",
                    contract_code="",
                    buy_or_sell=True,
                    amount=0,
                    exec_price=0,
                    take_profit_price=0,
                    take_profit_good_till=None,
                    take_profit_good_till_date=None,
                    stop_loss_price=0,
                    stop_loss_good_till=None,
                    stop_loss_good_till_date=None,
                    executed_time=datetime.now(timezone.utc),
                    floating=0,
                    revalue_rate=0,
                    commission=0,
                )
fxserver_client_lib.calc_Profit(openPos)
```

##### When success

No return value.

##### When failed (Failed to calculate position profit)

Exception occurred.

##### Caveat

As this function does not produce any return, it should combine with the use of `get_account_info()` to get the latest account information.

## Calculate account profit

Calculate the profit of the account

```python
# Send the request to FxServer
accountBal = AccountBalance(
                    settle_currency="",
                    display_currency="",
                    fixed_settlement_ex_rate=0,
                    credit_limit=0,
                    free_margin=0,
                    balance=0,
                    equity=0,
                    day_pnl=0,
                    floating_pnl=0,
                    margin_ratio=0,
                    margin_alert_ratio=0,
                    margin_call_ratio=0,
                    margin_cut_ratio=0,
                    margin_state=0,
                )
fxserver_client_lib.calc_account_profit(accountBal)
```

##### When success

No return value.

##### When failed (Failed to calculate account profit)

Exception occurred.

##### Caveat

As this function does not produce any return, it should combine with the use of `get_account_info()` to get the latest account information.

## Add price listener callback

Perform a series of user defined action when receiving price update event. For callback event argument, please refer to `PriceEvent` object in `entities.py`.

```python
contractName = input("Please input the contract name (default all):") or "all"

# This function is provided as an example for user-defined behavior.
# For example, this following function will print the bid and ask value based on the contract name whenever a price event is fired.
def callbackAction(event: PriceEvent):
    if (contractName == "all"):
        for contract in event.contract_codes:
            if (contractName == "all" or contract == contract_filter):
                print(f"Price event received: {contract}. " +
                        f"Bid Price: {fxserver_client_lib.get_price_info(contract).bid}. " +
                        f"Ask Price: {fxserver_client_lib.get_price_info(contract).ask}. " +
                        f"Price tag: {fxserver_client_lib.get_price_info(contract).tag}.")
            else:
                if (contractName in event.contract_codes):
                    print(f"Price event received: {contractName}. " +
                            f"Bid Price: {fxserver_client_lib.get_price_info(contractName).bid}. " +
                            f"Ask Price: {fxserver_client_lib.get_price_info(contractName).ask}. " +
                            f"Price tag: {fxserver_client_lib.get_price_info(contractName).tag}.")


callbackId = fxserver_client_lib.add_price_listener(callbackAction)
```

##### When success

Return the callback ID for the callback function.

##### When failed (Failed to add price listener)

Exception occurred.

##### Caveat

The callback function should be defined before calling this function.

## Remove price listener callback

Remove the callback function from the price listener list.

```python
fxserver_client_lib.remove_price_listener(callbackId)
```

##### When success

No return value.

##### When failed (Failed to remove price listener)

Exception occurred.

##### Caveat

The callback ID should be valid.

## Add Event listener callback

Perform a series of user defined action when receiving event update event. For callback event argument, please refer to the corresponding event object in `entities.py`.

```python

def handle_account_balance_update(event: AccountBalanceUpdateEvent):
    print("Account balance has been updated")

def handle_position_update(event: PositionUpdateEvent):
    print(f"Position updated for orders: {event.order_nos}")

def handle_contract_setting(event: ContractSettingEvent):
    print(f"Contract settings updated for: {event.contract_codes}")

def handle_order_update(event: OrderUpdateEvent):
    print(f"Orders updated: {event.order_nos}")

def handle_liquidation_update(event: LiquidationUpdateEvent):
    print("Liquidation update received")

def handle_login(event: LoginEvent):
    print("User logged in")

def handle_logout(event: LogoutEvent):
    print("User logged out")

def handle_server_event(event: ServerEventBase):
    print("General server event received")

def handle_system_message(event: SystemMessageEvent):
    print(f"System message: [{event.message_code}] {event.message_text}")

def handle_watchlist_update(event: WatchListUpdateEvent):
    print("Watchlist has been updated")

def handle_contract_subs_update(event: ContractSubsUpdateEvent):
    print(
        f"Contract subscriptions updated. FX Server completed: {event.fx_server_subs_completed}, "
        f"Price Agent completed: {event.price_agent_subs_completed}, "
        f"Contracts: {event.contract_subs}"
    )

def handle_connection_event(event: ConnectionEvent):
    print(
        f"Connection status changed - FX Server: {event.fx_server_connected}, "
        f"Price Agent: {event.price_agent_connected}"
    )

def handle_all_events(event: ServerEvent):
    print(f"Received event of type: {event.type}")

    # Handle each type of event
    if event.type == "AccountBalanceUpdateEvent":
        handle_account_balance_update(event)
    elif event.type == "PositionUpdateEvent":
        handle_position_update(event)
    elif event.type == "ContractSettingEvent":
        handle_contract_setting(event)
    elif event.type == "OrderUpdateEvent":
        handle_order_update(event)
    elif event.type == "LiquidationUpdateEvent":
        handle_liquidation_update(event)
    elif event.type == "LoginEvent":
        handle_login(event)
    elif event.type == "LogoutEvent":
        handle_logout(event)
    elif event.type == "ServerEvent":
        handle_server_event(event)
    elif event.type == "SystemMessageEvent":
        handle_system_message(event)
    elif event.type == "WatchListUpdateEvent":
        handle_watchlist_update(event)
    elif event.type == "ContractSubsUpdateEvent":
        handle_contract_subs_update(event)
    elif event.type == "ConnectionEvent":
        handle_connection_event(event)
    else:
        print(f"Unknown event type: {event.type}")

callback_id = fxserver_client_lib.add_event_listener(handle_all_events)
```

##### When success

Return the callback ID for the callback function.

##### When failed (Failed to add event listener)

Exception occurred.

## Remove Event listener callback

```python
fxserver_client_lib.remove_event_listener(callbackId)
```

##### When success

Return the callback ID for the callback function.

##### When failed (Failed to remove event listener)

Exception occurred.

## Change password

Request to change login password

```python
changePasReq = ChangePasswordRequest(old_password=123, new_password=456)
request_res = await fxserver_client_lib.change_password(changePasReq)
```

##### When success

No value returned

##### When failed (Failed to change password)

Exception occurred.

## Get Open Positions

Get all opened positions in the account

```python
positions = fxserver_client_lib.get_open_positions()
```

##### When success

`positions` object will hold a reference to a list of `OpenPosition` Python object when success. Please take reference to `OpenPosition` python object in `entities.py` for more details.

##### When failed (Failed to get open positions)

Exception occurred.
