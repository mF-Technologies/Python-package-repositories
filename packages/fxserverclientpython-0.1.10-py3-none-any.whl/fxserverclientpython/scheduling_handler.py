from asyncio import AbstractEventLoop
import asyncio
import logging

logger = logging.getLogger(__name__)


class SchedulingHandler:
    def __init__(self, loop: AbstractEventLoop):
        self.loop = loop
        self.interval_id = 0
        self.interval_tasks = {}

    def set_timeout(self, callback, ms=0):
        def wrapper():
            try:
                callback()
            except Exception:
                logger.exception("callback failed")
                raise

        if ms is None:
            ms = 0
        self.loop.call_later(ms / 1000, wrapper)

    async def run_interval(self, callback, delay_ms):
        """Run the callback every delay_ms milliseconds."""
        if delay_ms is None or delay_ms == 0:
            raise ValueError(f"Invalid delay ms {delay_ms}")

        while True:
            await asyncio.sleep(delay_ms / 1000)
            callback()

    def set_interval(self, callback, delay_ms):
        self.interval_id += 1
        self.interval_tasks[self.interval_id] = {
            "callback": callback,
            "delay_ms": delay_ms,
            "task": None,
        }

        task = asyncio.create_task(self.run_interval(callback, delay_ms))
        self.interval_tasks[self.interval_id]["task"] = task

        return self.interval_id

    def clear_interval(self, interval_id):
        if interval_id in self.interval_tasks:
            task = self.interval_tasks[interval_id]["task"]
            task.cancel()
            del self.interval_tasks[interval_id]
