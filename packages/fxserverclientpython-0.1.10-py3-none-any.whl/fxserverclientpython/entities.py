from typing import Annotated, List, Literal, Union, Optional, Callable, Dict
from datetime import datetime
from enum import Enum
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_serializer,
    model_validator,
)


def custom_capitalize(text: str) -> str:
    return text[:1].upper() + text[1:]


def to_camel(val: str) -> str:
    parts = val.split("_")
    return parts[0] + "".join(custom_capitalize(res) for res in parts[1:])


class GoodTill(Enum):
    GOOD_TILL_FRIDAY = 0
    GOOD_TILL_CANCEL = 1
    GOOD_TILL_DAY_END = 2


class LiquidationMethod(Enum):
    LIQUIDATION_METHOD_NO_LIQUIDATION = -1
    LIQUIDATION_METHOD_LIFO = 1
    LIQUIDATION_METHOD_FIFO = 2
    LIQUIDATION_METHOD_MANUAL = 3


class CamelBaseModel(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel, populate_by_name=True, exclude_none=True
    )


class ClientConfig(CamelBaseModel):
    endpoint: str
    machine_identifier: str
    price_agent_endpoint: str | list[str]
    trade_key: str
    webproxy_endpoint: str | list[str]
    terminal_type: str
    serverURL: Optional[str] = None

class InitReply(CamelBaseModel):
    pass


class LogoutReply(CamelBaseModel):
    pass


class AccountInfo(CamelBaseModel):
    account: str
    account_name: str
    bank_acc: List[str]


class AccountBalance(CamelBaseModel):
    settle_currency: str
    display_currency: str
    fixed_settlement_ex_rate: float
    credit_limit: float
    free_margin: float
    balance: float
    equity: float
    day_pnl: float
    floating_pnl: float
    margin_ratio: float
    margin_alert_ratio: float
    margin_call_ratio: float
    margin_cut_ratio: float
    margin_state: int


class ContractSetting(CamelBaseModel):
    contract_code: str
    symbol_name_EN: str
    symbol_name_TC: str
    symbol_name_SC: str
    decimal_places: int
    contract_size: float
    base_currency: str
    counter_currency: str
    bid_interest: float
    ask_interest: float
    min_lot_limit: float
    min_lot_increment_unit: float
    max_lot_limit: Optional[float]
    order_pips: float
    is_viewable: bool
    is_tradable: bool
    currency_type: int
    close_bid: float
    close_ask: float


class PriceInfo(CamelBaseModel):
    contract_code: str = ""
    bid: float = 0
    ask: float = 0
    high_bid: float = 0
    high_ask: float = 0
    low_bid: float = 0
    low_ask: float = 0
    tag: str = ""


class Order(CamelBaseModel):
    order_no: str
    contract_code: str
    buy_or_sell: bool
    limit_or_stop: bool
    request_price: float
    executed_price: float
    amount: float
    good_till: Optional[GoodTill] = None
    good_till_date: Optional[datetime] = None
    take_profit_price: float
    stop_loss_price: float
    liquidation_method: int
    liquidation_ref: Optional[str] = None
    created_time: datetime
    executed_time: Optional[datetime] = None
    cancelled_time: Optional[datetime] = None


class OpenPosition(CamelBaseModel):
    order_no: str
    contract_code: str
    buy_or_sell: bool
    amount: float
    exec_price: float
    take_profit_price: float
    take_profit_good_till: Optional[GoodTill] = None
    take_profit_good_till_date: Optional[datetime] = None
    stop_loss_price: float
    stop_loss_good_till: Optional[GoodTill] = None
    stop_loss_good_till_date: Optional[datetime] = None
    executed_time: datetime
    floating: float
    revalue_rate: float
    commission: float


class OpenPositionV2(OpenPosition):
    interest: float
    storage: float


class Liquidation(CamelBaseModel):
    contract_code: str
    is_buy_as_new_order: bool
    buy_order_no: str
    sell_order_no: str
    amount: float
    buy_executed_price: float
    sell_executed_price: float
    buy_executed_time: datetime
    sell_executed_time: datetime
    commission: float
    interest: float
    pnl: float
    new_pos_remarks: str
    liq_pos_remarks: str


class PasswordControl(CamelBaseModel):
    max_password_age: int
    symbol_list: str
    is_allow_reuse: bool
    min_length: int
    max_length: int
    min_lowercase_letter: int
    min_uppercase_letter: int
    min_digit_letter: int
    min_symbol_letter: int


class CommonRequest(CamelBaseModel):
    pass


class RequestReply(CamelBaseModel):
    pass


class LoginRequest(CamelBaseModel):
    username: str
    password: Optional[str] = None
    password_token: Optional[str] = None
    login_type: int


class LoginReply(RequestReply):
    trade_date: datetime
    tradable_contract: List[str]
    password_token: str
    password_age: int
    is_first_login: bool
    password_control: PasswordControl


class LoginReplyV2(LoginReply):
    max_watch_list: int
    max_market_subscription: int
    contract_subs: List[str]
    report_group_market_recommends: List[str]


class OrderStatusUpdate(CamelBaseModel):
    status: int
    description: str


# region [Manual Update]
class ManualUpdateNoReceive(CamelBaseModel):
    is_receive_update: bool = False


class ManualUpdateReceive(CamelBaseModel):
    is_receive_update: bool = True
    receive_update: Optional[Callable[[OrderStatusUpdate], None]] = None
    callback_id: Optional[str] = None

    model_config = {
        # Exclude receive_update from serialization since it's a function
        "json_excludes": {"receive_update"}
    }

    @field_serializer("receive_update")
    def serialize_receive_update(self, receive_update):
        # Return None for the function during serialization
        return None


ManualUpdate = Union[ManualUpdateNoReceive, ManualUpdateReceive]
# endregion


class AddOrderRequest(CamelBaseModel):
    contract_code: str
    price: float
    buy_or_sell: bool
    amount: float
    is_close: Optional[bool] = None
    good_till: GoodTill
    ref_order: Optional[str] = None
    comment: Optional[str] = None
    limit_or_stop: bool

    take_profit_present: bool = False
    take_profit_price: Optional[float] = None
    take_profit_good_till: Optional[GoodTill] = None
    trailing_stop_size: Optional[int] = None

    stop_loss_present: bool = False
    stop_loss_price: Optional[float] = None
    stop_loss_good_till: Optional[GoodTill] = None

    manual_update: Optional[ManualUpdate] = None


class AddOrderRequestReply(RequestReply):
    order_no: str
    contract_code: str
    buy_or_sell: bool
    request_price: float
    amount: float
    oco_ref: str
    take_profit_price: float
    stop_loss_price: float


class EditOrderRequest(CamelBaseModel):
    order_no: str
    price: float
    amount: float
    good_till: GoodTill
    comment: Optional[str] = None

    take_profit_present: bool = False
    take_profit_price: Optional[float] = None
    take_profit_good_till: Optional[GoodTill] = None
    trailing_stop_size: Optional[int] = None

    stop_loss_present: bool = False
    stop_loss_price: Optional[float] = None
    stop_loss_good_till: Optional[GoodTill] = None

    manual_update: Optional[ManualUpdate] = None


class EditOrderRequestReply(RequestReply):
    order_no: str
    contract_code: str
    buy_or_sell: bool
    request_price: float
    amount: float
    oco_ref: str
    take_profit_price: float
    stop_loss_price: float


class CancelOrderRequest(CamelBaseModel):
    order_no: str
    comment: Optional[str] = None


class CancelOrderReply(RequestReply):
    pass


class AddDealRequest(CamelBaseModel):
    contract_code: str
    price: Optional[float] = None
    buy_or_sell: bool
    accept_pips: float
    amount: float
    comment: str
    price_tag: Optional[str] = None

    take_profit_present: bool = False
    take_profit_price: Optional[float] = None
    take_profit_good_till: Optional[GoodTill] = None
    trailing_stop_size: Optional[int] = None

    stop_loss_present: bool = False
    stop_loss_price: Optional[float] = None
    stop_loss_good_till: Optional[GoodTill] = None

    manual_update: Optional[ManualUpdate] = None


class AddDealRequestReply(RequestReply):
    order_no: str
    contract_code: str
    buy_or_sell: bool
    request_price: float
    executed_price: float
    amount: float
    take_profit_price: float
    stop_loss_price: float


class EditDealOCOPairRequest(CamelBaseModel):
    order_no: str

    take_profit_present: bool = False
    take_profit_price: Optional[float] = None
    take_profit_good_till: Optional[GoodTill] = None
    trailing_stop_size: Optional[int] = None

    stop_loss_present: bool = False
    stop_loss_price: Optional[float] = None
    stop_loss_good_till: Optional[GoodTill] = None

    manual_update: Optional[ManualUpdate] = None


class EditDealOCOPairRequestReply(RequestReply):
    pass


class LiquidateRequest(CamelBaseModel):
    order_no: str
    accept_pips: float
    price: Optional[Union[int, float]] = None
    price_tag: Optional[str] = None
    amount: Optional[Union[int, float]] = None
    manual_update: Optional[ManualUpdate] = None


class LiquidateRequestReply(CamelBaseModel):
    liq_ref: str
    contract_code: str
    buy_or_sell: bool
    request_price: float
    executed_price: float
    amount: float
    oco_ref: str
    take_profit_price: float
    stop_loss_price: float


class LiquidateAllRequestReply(CamelBaseModel):
    liquidate_request_replies: List[LiquidateRequestReply]


class LiquidateAllRequestFIFO(CamelBaseModel):
    # liqRefs?: never. This value seems like intentional ignored in the Ts Code
    liq_refs: Optional[None] = None
    contract_code: str
    buy_or_sell: bool

    # Flag exception in case it present?
    @model_validator(mode="after")
    def check_liq_refs_not_present(self):
        if "liq_refs" in self.__pydantic_private__.extra:
            raise ValueError("liq_refs must not be provided for FIFO liquidation")
        return self


class LiquidateAllRequestCustom(CamelBaseModel):
    liq_refs: List[Dict[str, Union[int, float]]]
    contract_code: Optional[str] = None
    buy_or_sell: Optional[bool] = None


LiquidateAllRequestUnion = Union[LiquidateAllRequestFIFO, LiquidateAllRequestCustom]


class LiquidateAllRequest(CamelBaseModel):
    accept_pips: float
    amount: Optional[float] = None
    price: Optional[float] = None
    price_tag: Optional[str] = None

    # Fields from either FIFO or Custom
    # FIFO will have contract_code and buy_or_sell
    # Custom will have liq_refs
    liq_refs: Optional[List[Dict[str, Union[int, float]]]] = None
    contract_code: Optional[str] = None
    buy_or_sell: Optional[bool] = None
    manual_update: Optional[ManualUpdate] = None

    # Validation to ensure it's either FIFO or Custom
    @model_validator(mode="after")
    def validate_request_type(self):
        if self.liq_refs is not None and len(self.liq_refs) != 0:
            # Custom request, no need to keep checking as both contract code and
            # buy_or_sell can allow none
            pass
        else:
            # FIFO request, need to ensure contract code and
            # buy_or_sell is not none and liq_refs is none
            if self.contract_code is None:
                raise ValueError("contract_code is required for FIFO liquidation")
            if self.buy_or_sell is None:
                raise ValueError("buy_or_sell is required for FIFO liquidation")
            if self.liq_refs is not None:
                raise ValueError("liq_refs is not allowed for FIFO liquidation")

        # Validate ManualUpdate part
        if self.manual_update and (
            isinstance(self.manual_update, (ManualUpdateReceive, ManualUpdateNoReceive))
        ):
            if (
                self.manual_update.is_receive_update
                and self.manual_update.receive_update is None
            ):
                raise ValueError(
                    "receive_update is required when is_receive_update is True"
                )

        return self


class ChangePasswordRequest(CamelBaseModel):
    old_password: str
    new_password: str


class ChangePasswordResponse(RequestReply):
    pass


class SearchContractRequest(CamelBaseModel):
    keyword: str
    result_limit: int


class SearchContractInfo(CamelBaseModel):
    contract_code: str
    symbol_name_EN: str
    symbol_name_TC: str
    symbol_name_SC: str


class SearchContractRequestReply(RequestReply):
    search_contract_infos: List[SearchContractInfo]


class PriceSnapshotRequest(CamelBaseModel):
    contract_codes: List[str]


class PriceSnapshotInfo(CamelBaseModel):
    contract_code: str
    bid: float
    ask: float
    tag: str
    decimal_place: int
    close_bid: float
    close_ask: float


class PriceSnapshotRequestReply(CamelBaseModel):
    price_snapshot_infos: List[PriceSnapshotInfo]


class PlatformInfoReply(RequestReply):
    market_recommand: List[str]
    max_watch_list: int
    max_market_subscription: int


class ChartInformationReply(RequestReply):
    mapping: List[Dict[str, str]]


class CommonServerEvent(CamelBaseModel):
    pass


class PriceEvent(CommonServerEvent):
    type: str = "price"
    contract_codes: List[str]


class AccountBalanceUpdateEvent(CamelBaseModel):
    type: Literal["AccountBalanceUpdateEvent"]


class PositionUpdateEvent(CamelBaseModel):
    type: Literal["PositionUpdateEvent"]
    order_nos: List[str]


class ContractSettingEvent(CamelBaseModel):
    type: Literal["ContractSettingEvent"]
    contract_codes: List[str]


class OrderUpdateEvent(CamelBaseModel):
    type: Literal["OrderUpdateEvent"]
    order_nos: List[str]


class LiquidationUpdateEvent(CamelBaseModel):
    type: Literal["LiquidationUpdateEvent"]


class LoginEvent(CamelBaseModel):
    type: Literal["LoginEvent"]


class LogoutEvent(CamelBaseModel):
    type: Literal["LogoutEvent"]


class ServerEventBase(CamelBaseModel):
    type: Literal["ServerEvent"]


class SystemMessageEvent(CamelBaseModel):
    type: Literal["SystemMessageEvent"]
    message_code: Union[str, int]
    message_text: str


class WatchListUpdateEvent(CamelBaseModel):
    type: Literal["WatchListUpdateEvent"]


class ContractSubsUpdateEvent(CamelBaseModel):
    type: Literal["ContractSubsUpdateEvent"]
    fx_server_subs_completed: bool
    price_agent_subs_completed: bool
    contract_subs: List[str]


class ConnectionEvent(CamelBaseModel):
    type: Literal["ConnectionEvent"]
    fx_server_connected: bool
    price_agent_connected: bool


# endregion

ServerEvent = Annotated[
    Union[
        AccountBalanceUpdateEvent,
        PositionUpdateEvent,
        ContractSettingEvent,
        OrderUpdateEvent,
        LiquidationUpdateEvent,
        LoginEvent,
        LogoutEvent,
        ServerEventBase,
        SystemMessageEvent,
        WatchListUpdateEvent,
        ContractSubsUpdateEvent,
        ConnectionEvent,
    ],
    Field(discriminator="type"),
]


class GuestPriceAgentServerEvent(CamelBaseModel):
    type: str = "GuestPriceAgentConnectionEvent"


class UpdateWatchListRequest(CamelBaseModel):
    watch_list: List[str]


class UpdateWatchListRequestReply(RequestReply):
    success: bool

class ExceptionWithStatusCode(CamelBaseModel):
    statusCode: str
    message: str
    extra: Dict[str, str]

if __name__ == "__main__":
    out = ContractSetting.model_validate_json(
        '{"contractCode":"USDHKD","symbolNameEN":"HKD","symbolNameTC":"港元","symbolNameSC":"港元","decimalPlaces":5,"contractSize":150,"baseCurrency":"USD","counterCurrency":"HKD","bidInterest":0,"askInterest":0,"minLotLimit":123,"minLotIncrementUnit":0.1,"maxLotLimit":30,"orderPips":0,"isViewable":false,"isTradable":false,"currencyType":0,"closeBid":7.77581,"closeAsk":7.77613}'
    )
    print(out)
