import asyncio


class PythonCallableFunction:
    CONNECT_WS_FROM_PYTHON = "connectWsFromPython"
    ON_SEND_WS_FROM_PYTHON = "onSendWsFromPython"
    PYTHON_LOG = "pythonLog"
    PYTHON_ERROR = "pythonError"
    PYTHON_SET_TIMEOUT = "setTimeout"
    PYTHON_SET_INTERVAL = "setInterval"
    PYTHON_CLEAR_INTERVAL = "clearInterval"


class FutureManager:
    def __init__(self, loop: asyncio.AbstractEventLoop):
        self.__future_map = {}
        self.__id = 0
        self.__loop = loop

    def gen_future(self) -> int:
        self.__id += 1
        self.__future_map[self.__id] = self.__loop.create_future()
        return self.__id

    async def get_result(self, _id: int):
        res = await self.__future_map[_id]
        del self.__future_map[_id]
        return res

    def resolve(self, _id: int, res: any):
        f = self.__future_map[_id]
        f.set_result(res)

    def error(self, _id: int, err: any):
        f = self.__future_map[_id]
        f.set_exception(Exception(err))


class GcManger:
    JS_MEMORY_LIMIT = 100 * 1024 * 1024
    GC_RATIO = 70

    def __init__(self, context):
        self.__context = context
        self.__context.set_memory_limit(GcManger.JS_MEMORY_LIMIT)

    def start(self):
        asyncio.create_task(self.__check_gc())

    async def __check_gc(self):
        while True:
            await asyncio.sleep(15)
            if self.__is_exceed_ratio():
                self.__context.gc()

    def __is_exceed_ratio(self):
        return (
            self.__context.memory()["memory_used_size"]
            / self.__context.memory()["malloc_limit"]
            * 100
        ) >= GcManger.GC_RATIO
