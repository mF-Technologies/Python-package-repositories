class AbortSignal {
    constructor() {
        this.aborted = false;
        this.onabort = null;
        this._listeners = [];
    }

    addEventListener(event, listener) {
        if (event === "abort" && typeof listener === "function") {
            this._listeners.push(listener);
        }
    }

    removeEventListener(event, listener) {
        if (event === "abort") {
            this._listeners = this._listeners.filter(l => l !== listener);
        }
    }
}


class AbortController {
    constructor() {
        this.signal = new AbortSignal();
    }
    abort() {
        if (!this.signal.aborted) {
            this.signal.aborted = true;

            if (typeof this.signal.onabort === "function") {
                this.signal.onabort();
            }
 
            for (let listener of this.signal._listeners) {
                listener();
            }
        }
    }
}

globalThis.AbortController = AbortController;
globalThis.AbortSignal = AbortSignal;