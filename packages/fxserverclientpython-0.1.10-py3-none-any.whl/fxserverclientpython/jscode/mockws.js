const LUT_HEX_4b = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'];
const LUT_HEX_8b = new Array(0x100);
for (let n = 0; n < 0x100; n++) {
  LUT_HEX_8b[n] = `${LUT_HEX_4b[(n >>> 4) & 0xF]}${LUT_HEX_4b[n & 0xF]}`;
}

function toHex(buffer) {
    let out = '';
    for (let idx = 0, edx = buffer.length; idx < edx; idx++) {
      out += LUT_HEX_8b[buffer[idx]];
    }
    return out;
}

function hexToUint8Array(hexString) {
    return Uint8Array.from({ length: hexString.length / 2 }, (_, i) => 
        parseInt(hexString.substr(i * 2, 2), 16)
    );
}

class MockWebSocket {
    constructor(url) {
        this.url = url;
        this._readyState = 0;  // 0 = CONNECTING, 1 = OPEN, 2 = CLOSING, 3 = CLOSED
        this.onopen = null;
        this.onmessage = null;
        this.onerror = null;
        this.onclose = null;

        this._id = connectWsFromPython(this.url, 
            () => this._open(),
            (msg) => this.receiveMessage(msg),
            (code, reason, message) => this.triggerClose(code, reason, message)
        )
    }

    get readyState() {
        return this._readyState;
    }

    send(data) {
        if (this._readyState !== 1) {
            throw new Error("WebSocket is not open");
        }

        // Handle different data types
        let processedData = data;
        if (data instanceof ArrayBuffer) {
            processedData = new Uint8Array(data);
        } else if (data instanceof Uint8Array) {
            processedData = data;  // ArrayBufferView approximation
        } else if (typeof data === 'string') {
            processedData = data;
        } // Blob could be simulated as string or Uint8Array if needed
        onSendWsFromPython(this._id, toHex(processedData));
    }

    close(code, reason, message) {
        if (this._readyState === 1) {
            this._readyState = 2;  // CLOSING
            if (this.onclose) {
                this.onclose({
                    code,
                    reason,
                    message
                });
            }
            this._readyState = 3;  // CLOSED
        }
    }

    // Internal method to simulate opening
    _open() {
        this._readyState = 1;  // OPEN
        if (this.onopen) {
            this.onopen.call(null);
        }
    }

    // Methods to simulate events from Python
    receiveMessage(data) {
        if (this._readyState === 1 && this.onmessage) {
            this.onmessage({data: hexToUint8Array(data)});
        }
    }

    triggerError(error) {
        if (this.onerror) {
            this.onerror(error);
        }
    }

    triggerClose(code, reason, message) {
        this.close(code, reason, message);
    }
}

globalThis.MockWebSocket = MockWebSocket;