from abc import abstractmethod, ABC
from .entities import *


class FxServerClientApi(ABC):
    @abstractmethod
    async def logout(self) -> None:
        pass

    @abstractmethod
    def get_account_info(self) -> AccountInfo:
        pass

    @abstractmethod
    def get_account_balance(self) -> AccountBalance:
        pass

    @abstractmethod
    def get_contract_setting(self) -> list[ContractSetting]:
        pass

    @abstractmethod
    def get_price_info(self, symbol: str) -> PriceInfo:
        pass

    @abstractmethod
    async def add_order(self, request: AddOrderRequest) -> AddOrderRequestReply:
        pass

    @abstractmethod
    async def edit_order(self, request: EditOrderRequest) -> EditOrderRequestReply:
        pass

    @abstractmethod
    async def cancel_order(self, request: CancelOrderRequest) -> CancelOrderReply:
        pass

    @abstractmethod
    async def add_deal(self, request: AddDealRequest) -> AddDealRequestReply:
        pass

    @abstractmethod
    async def edit_deal_oco_pair(
        self, request: EditDealOCOPairRequest
    ) -> EditDealOCOPairRequestReply:
        pass

    @abstractmethod
    async def liquidate(self, request: LiquidateRequest) -> LiquidateRequestReply:
        pass

    @abstractmethod
    async def liquidate_all(
        self, request: LiquidateAllRequest
    ) -> LiquidateAllRequestReply:
        pass

    @abstractmethod
    def get_pending_orders(self) -> list[Order]:
        pass

    @abstractmethod
    def get_executed_orders_today(self) -> list[str]:
        pass

    @abstractmethod
    def get_cancelled_orders_today(self) -> list[str]:
        pass

    @abstractmethod
    def get_liquidations(self) -> list[Liquidation]:
        pass

    @abstractmethod
    def get_executed_order_for_positions(
        self,
    ) -> dict[Union[int, float], Union[int, float]]:
        pass

    @abstractmethod
    def get_position_for_executed_orders(
        self,
    ) -> dict[Union[int, float], Union[int, float]]:
        pass

    @abstractmethod
    def get_order_info(self, order_no: str) -> Order | None:
        pass

    @abstractmethod
    async def get_executed_order_history(
        self, from_date: str, to_date: str
    ) -> list[Order]:
        pass

    @abstractmethod
    async def get_cancelled_order_history(
        self, from_date: str, to_date: str
    ) -> list[Order]:
        pass

    @abstractmethod
    async def get_liquidation_history(
        self, from_date: str, to_date: str
    ) -> list[Liquidation]:
        pass

    @abstractmethod
    def calc_Profit(self, position: OpenPosition):
        pass

    @abstractmethod
    def calc_account_profit(self, account: AccountBalance):
        pass

    @abstractmethod
    def add_price_listener(self, callback: Callable[[PriceEvent], None]) -> str:
        pass

    @abstractmethod
    def remove_price_listener(self, callback_id: str):
        pass

    @abstractmethod
    def add_event_listener(self, callback: Callable[[ServerEvent], None]) -> str:
        pass

    @abstractmethod
    def remove_event_listener(self, callback_id: str):
        pass

    @abstractmethod
    async def change_password(
        self, request: ChangePasswordRequest
    ) -> ChangePasswordResponse:
        pass

    @abstractmethod
    async def login(self) -> LoginReply:
        pass

    @abstractmethod
    def get_open_positions(self) -> list[OpenPosition]:
        pass
