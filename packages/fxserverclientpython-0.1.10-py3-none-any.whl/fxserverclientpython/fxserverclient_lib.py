import uuid
import asyncio
import os
import json
import logging
import quickjs
import requests

from fxserverclientpython.errorCodeMapping import ErrorCodeMapping
from .api import FxServerClientApi
from .utility import PythonCallableFunction, FutureManager, GcManger
from .entities import *
from .scheduling_handler import SchedulingHandler
from .websocket_client import WebSocketClientManager
from getmac import get_mac_address


logger = logging.getLogger(__name__)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
error_mapper = ErrorCodeMapping()

class FxServerClientLib(FxServerClientApi):
    def __init__(self, loop: asyncio.AbstractEventLoop):
        self.__pending_job_timeout = 5
        self.__loop = loop
        self.__pending_execution_task = None
        self.__context = quickjs.Context()
        self.__node_env = "production"
        self.__scheduling_handler = SchedulingHandler(loop)
        self.__ws_manager = WebSocketClientManager()
        self.__future_manager = FutureManager(loop)
        self.__gc_manager = GcManger(self.__context)
        self._callback_registries = {"price": {}, "general": {}}
        self._client_config: ClientConfig = None
        self._login_request: LoginRequest = None

        self.__gc_manager.start()
        self.__inject_js_content()
        self.__load_js_code()

    def __inject_js_content(self):
        self.__context.add_callable(
            PythonCallableFunction.CONNECT_WS_FROM_PYTHON, self.__connect_server
        )

        self.__context.add_callable(
            PythonCallableFunction.ON_SEND_WS_FROM_PYTHON, self.__send_msg
        )

        self.__context.add_callable(
            PythonCallableFunction.PYTHON_LOG,
            lambda data: logger.info("js log: %s", data),
        )

        self.__context.add_callable(
            PythonCallableFunction.PYTHON_ERROR,
            lambda data: logger.error("js error: %s", data),
        )

        self.__context.add_callable(
            PythonCallableFunction.PYTHON_SET_TIMEOUT,
            self.__scheduling_handler.set_timeout,
        )

        self.__context.add_callable(
            PythonCallableFunction.PYTHON_SET_INTERVAL,
            self.__scheduling_handler.set_interval,
        )

        self.__context.add_callable(
            PythonCallableFunction.PYTHON_CLEAR_INTERVAL,
            self.__scheduling_handler.clear_interval,
        )

        self.__context.add_callable(
            "pythonHandlePriceEvent",
            lambda callback_id, event_json: self.__handle_callback(
                "price", callback_id, event_json
            ),
        )

        self.__context.add_callable(
            "pythonHandleGeneralEvent",
            lambda callback_id, event_json: self.__handle_callback(
                "general", callback_id, event_json
            ),
        )

        self.__context.eval(
            f'globalThis.process = {{ env: {{ NODE_ENV: "{self.__node_env}" }} }};'
        )

        self.__context.eval(
            """
            globalThis.console = {
                log: pythonLog,
                error: pythonError
            };
                          
            function getPriceHelper(client, symbol) {
                let price = {};
                const success = client.getPriceInfo(symbol, price);
                if (success == -1) {
                    return null;          
                } else {
                    return price;
                }
            }

            function getResultHelper(func, outputHolder) {
                func(outputHolder)
                return outputHolder
            }
        """
        )

        self.__context.eval(
            """
            // Setup callback bridge for price events
            globalThis.pythonCallbacks = {
                handlePriceEvent: function(callbackId, event) 
                {
                    pythonHandlePriceEvent(callbackId, JSON.stringify(event));
                    return true;
                },
                handleGeneralEvent: function(callbackId, event) {
                    pythonHandleGeneralEvent(callbackId, JSON.stringify(event));
                    return true;
                }
            };
        """
        )

    def __load_js_code(self) -> None:
        js_code_dir = os.path.join(SCRIPT_DIR, "./jscode")
        js_file_paths = []
        for f in os.listdir(js_code_dir):
            if f.endswith("js"):
                path = os.path.join(js_code_dir, f)
                js_file_paths.append(os.path.normpath(path))

        logger.info("Load below js file: %s", js_file_paths)

        for path in js_file_paths:
            with open(path, "r", encoding="utf-8") as f:
                self.__context.eval(f.read())

    def __connect_server(self, url, onopen, onmessage, onclose):
        ws_id = self.__ws_manager.create_ws_client(url, onopen, onmessage, onclose)
        return ws_id

    def __send_msg(self, ws_id: int, msg: str):
        self.__loop.create_task(self.__ws_manager.send_msg(ws_id, msg))

    async def __execute_pending_jobs(self):
        while True:
            if self.__context.execute_pending_job():
                continue

            future = self.__loop.create_future()

            def check_pending():
                if not future.done():
                    if self.__context.execute_pending_job():
                        future.set_result(True)
                    else:
                        # Reschedule check
                        self.__loop.call_soon(check_pending)

            self.__loop.call_soon(check_pending)

            try:
                await asyncio.wait_for(future, self.__pending_job_timeout)
            except asyncio.TimeoutError:
                pass
                # print("No JS jobs for a while...")

    async def __call_async_js_func(self, js_func: str):
        f_id = self.__future_manager.gen_future()
        self.__context.eval(
            f"""
            {js_func}
                  .then(res => resultCallback({f_id}, JSON.stringify(res)))
                  .catch(err => errorCallback({f_id}, JSON.stringify(err, Object.getOwnPropertyNames(err))));
        """
        )
        return await self.__future_manager.get_result(f_id)

    def __call_js_func(self, js_expression: str) -> str | None:
        res = self.__context.eval(
            f"""
            JSON.stringify({js_expression});
        """
        )
        if res == "null":
            return None
        return res

    def __handle_callback(self, registry_type, callback_id, event_json):
        if callback_id in self._callback_registries[registry_type]:
            callback = self._callback_registries[registry_type][callback_id]
            try:
                event_data = json.loads(event_json)

                # Convert to the appropriate event type
                if registry_type == "price":
                    event = PriceEvent(**event_data)
                else:  # 'general'
                    # Determine the event type from the data and create the appropriate event object
                    event_type = event_data.get("type", "ServerEvent")
                    event_class = globals().get(event_type, ServerEvent)
                    event = event_class(**event_data)

                callback(event)
            except Exception as e:
                logger.error("Error handling %s event callback: %s", registry_type, e)

    def init(self, config: dict[str, str]):
        self.user_config_validation(config)
        self.__pending_execution_task = asyncio.create_task(
            self.__execute_pending_jobs()
        )

        self.__context.add_callable("resultCallback", self.__future_manager.resolve)
        self.__context.add_callable("errorCallback", self.__future_manager.error)

        json_param = self._client_config.model_dump_json(by_alias=True, exclude_none=True)

        self.__context.eval(
            """
            function convertFromPythonConfig(config) {
                return {
                    echoServer: async () => '',
                    webSocket: (url) => {
                        return new MockWebSocket(url);
                    },
                    ...config          
                }
            }
        """
        )

        self.__context.eval(
            f"""
            let config = convertFromPythonConfig({json_param});
            const app = fxClientLib.createClientWithStore(config);
            const client = app.client;
        """
        )

    def user_config_validation(self, user_config: dict[str, str]):
        """
        Check whether the user contain necessary item inside the user_config object.user_config should contain following items:
        - endpoint
        - price_agent_endpoint
        - trade_key
        - webproxy_endpoint
        - username
        - valid_generated_token
        
        Args:
            user_config: The user configuration dictionary to validate
        
        Returns:
            A list of missing items in the configuration for both setup and user section
        """
        missing_items = []
        
        required_fields = [
            'endpoint', 
            'price_agent_endpoint', 
            'trade_key', 
            'webproxy_endpoint',
            'username',
            'valid_generated_token'
        ]

        for field in required_fields:
            if field not in user_config:
                missing_items.append(f"{field}")

        if (len(missing_items) != 0):
            raise ValueError("Missing the followings items inside the user config: " + ',' .join(missing_items))
        
        self._client_config = self.construct_client_config(user_config)
        self._login_request = self.construct_login_request(user_config)
        

    def construct_client_config(self, user_config_dict: dict[str, str]) -> ClientConfig:
        config = ClientConfig(
            machine_identifier=get_mac_address(),
            endpoint=user_config_dict.get("endpoint"),
            price_agent_endpoint=user_config_dict.get("price_agent_endpoint"),
            trade_key=user_config_dict.get("trade_key"),
            webproxy_endpoint=user_config_dict.get("webproxy_endpoint"),
            terminal_type="web",
            serverURL=None
        )
        return config
    
    def construct_login_request(self, user_config_dict: dict[str, str]) -> LoginRequest:
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'PythonLibrary',
            'Authorization': f'Bearer {user_config_dict.get("valid_generated_token")}'
        }

        cookies = {
            'CompanyName': 'ebl'
        }
        request = requests.post(user_config_dict.get("webproxy_endpoint") + "/api/tokens/auth", headers=headers, cookies=cookies)
        request.raise_for_status()
        response = request.json()

        login_request = LoginRequest(
            username=user_config_dict.get("username"),
            password=None,
            login_type=1,
            password_token=response.get("access_token")
        )
        return login_request

    async def logout(self) -> None:
        await self.__call_async_js_func("client.logout()")

    def get_account_info(self) -> AccountInfo:
        json_res = self.__call_js_func("client.getAccountInfo()")
        return AccountInfo.model_validate_json(json_res)

    def get_account_balance(self) -> AccountBalance:
        json_res = self.__call_js_func("client.getAccountBalance()")
        return AccountBalance.model_validate_json(json_res)

    def get_contract_setting(self) -> list[ContractSetting]:
        json_res = self.__call_js_func("client.getContractSetting()")

        return [ContractSetting.model_validate(item) for item in json.loads(json_res)]

    def get_price_info(self, symbol: str) -> PriceInfo | None:
        json_res = self.__call_js_func(f"getPriceHelper(client, '{symbol}')")
        if json_res in ("null", None):
            return None
        return PriceInfo.model_validate_json(json_res)

    async def add_order(self, request: AddOrderRequest) -> AddOrderRequestReply:
        json_request = request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(f"client.addOrder({json_request})")
        return AddOrderRequestReply.model_validate_json(json_res)

    async def edit_order(self, request: EditOrderRequest) -> EditOrderRequestReply:
        json_request = request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(f"client.editOrder({json_request})")
        return EditOrderRequestReply.model_validate_json(json_res)

    async def cancel_order(self, request: CancelOrderRequest) -> CancelOrderReply:
        json_request = request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(
            f"client.cancelOrder({json_request})"
        )
        return CancelOrderReply.model_validate_json(json_res)

    async def add_deal(self, request: AddDealRequest) -> AddDealRequestReply:
        json_request = request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(f"client.addDeal({json_request})")
        return AddDealRequestReply.model_validate_json(json_res)

    async def edit_deal_oco_pair(
        self, request: EditDealOCOPairRequest
    ) -> EditDealOCOPairRequestReply:
        json_request = request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(
            f"client.editDealOCOPair({json_request})"
        )
        return EditDealOCOPairRequestReply.model_validate_json(json_res)

    async def liquidate(self, request: LiquidateRequest) -> LiquidateRequestReply:
        json_request = request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(f"client.liquidate({json_request})")

        try:
            data = json.loads(json_res)
            return LiquidateRequestReply.model_validate(data)
        except json.JSONDecodeError as e:
            logger.error(
                "Failed to parse JSON response",
                extra={
                    "error": str(e),
                    "json_response": json_res,
                },
            )
            return []

        '''
        # Handle callback registration, currently does not work
        if (request_copy["manualUpdate"] and 
            request_copy["manualUpdate"]["isReceiveUpdate"]):
        
            # Generate a unique callback ID
            callback_id = f"py_callback_{int(datetime.now().timestamp() * 1000)}_{random.randint(1000, 9999)}"
        
            # Register the callback
            self._callback_registries['general'][callback_id] = request_copy["manualUpdate"]["isReceiveUpdate"]
        
            # Create a JavaScript function that will call back to Python
            self.context.eval(f"""
            // Create a function that will call back to Python with the given ID
                globalThis.{callback_id} = function(update) {{
                    pythonCallbacks.handleGeneralEvent("{callback_id}", update);
                    return true;
                }};
            """)
        
            # Update the request dictionary to use this function
            request_copy["manualUpdate"] = {
                "isReceiveUpdate": True,
                # Reference the JavaScript function we just created
                "receiveUpdate": f"__FUNCTION__{callback_id}__"
            }
        
        # At this point request_dict has a string reference to a JavaScript function
        # But we need to evaluate it to get the actual function reference
        json_request = json.dumps(request_copy)
        
        # Replace the string reference with an actual function reference using JS eval
        json_request = json_request.replace(f'"__FUNCTION__{callback_id}__"', f"globalThis.{callback_id}")
        
        print(f"JSON being sent to JS: {json_request}")
        json_res = await self.__call_async_js_func(f"client.liquidate({json_request})")

        try:
            data = json.loads(json_res)
            return LiquidateRequestReply.model_validate(data)
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON: {e}")
            return []
        '''

    async def liquidate_all(
        self, request: LiquidateAllRequest
    ) -> LiquidateAllRequestReply:
        # Deep copy to avoid modifying original
        json_request = request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(
            f"client.liquidateAll({json_request})"
        )

        try:
            data = json.loads(json_res)
            return LiquidateAllRequestReply.model_validate(data)
        except json.JSONDecodeError as e:
            logger.error(
                "Failed to parse JSON response",
                extra={
                    "error": str(e),
                    "json_response": json_res,
                },
            )
            return []

        '''
        # Handle callback registration
        if (request_copy["manualUpdate"] and 
            request_copy["manualUpdate"]["isReceiveUpdate"]):
        
            # Generate a unique callback ID
            callback_id = f"py_callback_{int(datetime.now().timestamp() * 1000)}_{random.randint(1000, 9999)}"
        
            # Register the callback
            self._callback_registries['general'][callback_id] = request_copy["manualUpdate"]["isReceiveUpdate"]
        
            # Create a JavaScript function that will call back to Python
            self.context.eval(f"""
            // Create a function that will call back to Python with the given ID
                globalThis.{callback_id} = function(update) {{
                    pythonCallbacks.handleGeneralEvent("{callback_id}", update);
                    return true;
                }};
            """)
        
            # Update the request dictionary to use this function
            request_copy["manualUpdate"] = {
                "isReceiveUpdate": True,
                # Reference the JavaScript function we just created
                "receiveUpdate": f"__FUNCTION__{callback_id}__"
            }
        
        # At this point request_dict has a string reference to a JavaScript function
        # But we need to evaluate it to get the actual function reference
        json_request = json.dumps(request_copy)
        
        # Replace the string reference with an actual function reference using JS eval
        json_request = json_request.replace(f'"__FUNCTION__{callback_id}__"', f"globalThis.{callback_id}")
        
        print(f"JSON being sent to JS: {json_request}")
        json_res = await self.__call_async_js_func(f"client.liquidateAll({json_request})")
        
        try:
            data = json.loads(json_res)
            return LiquidateAllRequestReply.model_validate_json(data)
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON: {e}")
            return []
        '''

    def get_pending_orders(self) -> list[Order]:
        json_res = self.__call_js_func("client.getPendingOrders()")
        try:
            data = json.loads(json_res)
            return [Order.model_validate(order) for order in data]
        except json.JSONDecodeError as e:
            logger.error(
                "Failed to parse JSON response",
                extra={
                    "error": str(e),
                    "json_response": json_res,
                },
            )
            return []

    def get_executed_orders_today(self) -> list[str]:
        json_res = self.__call_js_func("client.getExecutedOrdersToday()")
        return json_res

    def get_cancelled_orders_today(self) -> list[str]:
        json_res = self.__call_js_func("client.getCancelledOrdersToday()")
        return json_res

    def get_liquidations(self) -> list[Liquidation]:
        json_res = self.__call_js_func("client.getLiquidations()")

        try:
            data = json.loads(json_res)
            return [Liquidation.model_validate(liquidation) for liquidation in data]
        except json.JSONDecodeError as e:
            logger.error(
                "Failed to parse JSON response",
                extra={
                    "error": str(e),
                    "json_response": json_res,
                },
            )
            return []

    def get_executed_order_for_positions(
        self,
    ) -> dict[Union[int, float], Union[int, float]]:
        json_res = self.__call_js_func("client.getExecutedOrderForPositions()")

        try:
            position_dict = json.loads(json_res)
            return position_dict
        except json.JSONDecodeError:
            return {}

    def get_position_for_executed_orders(
        self,
    ) -> dict[Union[int, float], Union[int, float]]:
        json_res = self.__call_js_func("client.getPositionForExecutedOrders()")
        if json_res in ("null", None, "[]") or not json_res:
            return {}

        try:
            position_dict = json.loads(json_res)
            return position_dict
        except json.JSONDecodeError:
            return {}

    def get_order_info(self, order_no: str) -> Order | None:
        json_res = self.__call_js_func(f"client.getOrderInfo({order_no})")
        if json_res in ("null", None, "[]") or not json_res:
            return None
        return Order.model_validate_json(json_res)

    async def get_executed_order_history(
        self, from_date: str, to_date: str
    ) -> list[Order]:
        json_res = await self.__call_async_js_func(
            f"client.getExecutedOrderHistory(new Date('{from_date}'), new Date('{to_date}'))"
        )
        if json_res in ("null", None, "[]") or not json_res:
            return []

        try:
            data = json.loads(json_res)
            return [Order.model_validate(order) for order in data]
        except json.JSONDecodeError as e:
            logger.error(
                "Failed to parse JSON response",
                extra={
                    "error": str(e),
                    "json_response": json_res,
                },
            )
            return []

    async def get_cancelled_order_history(
        self, from_date: str, to_date: str
    ) -> list[Order]:
        json_res = await self.__call_async_js_func(
            f"client.getCancelledOrderHistory(new Date('{from_date}'), new Date('{to_date}'))"
        )
        if json_res in ("null", None, "[]") or not json_res:
            return []

        try:
            data = json.loads(json_res)
            return [Order.model_validate(order) for order in data]
        except json.JSONDecodeError as e:
            logger.error(
                "Failed to parse JSON response",
                extra={
                    "error": str(e),
                    "json_response": json_res,
                },
            )
            return []

    async def get_liquidation_history(
        self, from_date: str, to_date: str
    ) -> list[Liquidation]:
        json_res = await self.__call_async_js_func(
            f"client.getLiquidationHistory(new Date('{from_date}'), new Date('{to_date}'))"
        )
        if json_res in ("null", None, "[]") or not json_res:
            return []

        try:
            data = json.loads(json_res)
            return [Liquidation.model_validate(liquidation) for liquidation in data]
        except json.JSONDecodeError as e:
            logger.error(
                "Failed to parse JSON response",
                extra={
                    "error": str(e),
                    "json_response": json_res,
                },
            )
            return []

    def calc_Profit(self, position: OpenPosition):
        json_request = position.model_dump_json(by_alias=True, exclude_none=True)
        json_res = self.__call_js_func(f"getResultHelper(client.calcProfit, {json_request})")
        return OpenPosition.model_validate_json(json_res)


    def calc_account_profit(self, account: AccountBalance):
        json_request = account.model_dump_json(by_alias=True, exclude_none=True)
        json_res = self.__call_js_func(f"getResultHelper(client.calcAccountProfit, {json_request})")
        return AccountBalance.model_validate_json(json_res)

    def add_price_listener(self, callback: Callable[[PriceEvent], None]) -> str:
        callback_id = str(uuid.uuid4())

        # Store the callback in our registry
        self._callback_registries["price"][callback_id] = callback

        # Create a JavaScript callback that will bridge to Python
        js_code = f"""
        (function() {{
            const callbackId = '{callback_id}';
            return client.addPriceListener(function(event) {{
                pythonCallbacks.handlePriceEvent(callbackId, event);
            }});
        }})()
        """
        return self.__call_js_func(js_code)

    def remove_price_listener(self, callback_id: str):
        if callback_id in self._callback_registries["price"]:
            del self._callback_registries["price"][callback_id]
        return self.__call_js_func(f"client.removePriceListener('{callback_id}')")

    def add_event_listener(self, callback: Callable[[ServerEvent], None]) -> str:
        callback_id = str(uuid.uuid4())
        self._callback_registries["general"][callback_id] = callback

        js_code = f"""
        (function() {{
            const callbackId = '{callback_id}';
            return client.addEventListener(function(event) {{
            pythonCallbacks.handleGeneralEvent(callbackId, event);
            }});
        }})()
        """
        return self.__call_js_func(js_code)

    def remove_event_listener(self, callback_id: str):
        if callback_id in self._callback_registries["general"]:
            del self._callback_registries["general"][callback_id]
        return self.__call_js_func(f"client.removeEventListener('{callback_id}')")

    async def change_password(
        self, request: ChangePasswordRequest
    ) -> ChangePasswordResponse:
        json_request = request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(
            f"client.changePassword({json_request})"
        )
        return ChangePasswordResponse.model_validate_json(json_res)

    async def login(self) -> LoginReply:
        json_login_req = self._login_request.model_dump_json(by_alias=True, exclude_none=True)
        json_res = await self.__call_async_js_func(f"client.login({json_login_req})")
        return LoginReply.model_validate_json(json_res)

    def get_open_positions(self) -> list[OpenPosition]:
        json_res = self.__call_js_func("client.getOpenPositions()")
        if json_res in ("null", None, "[]") or not json_res:
            return []

        try:
            positions_data = json.loads(json_res)
            return [
                OpenPosition.model_validate(position) for position in positions_data
            ]
        except json.JSONDecodeError as e:
            logger.error(
                "Failed to parse JSON response",
                extra={
                    "error": str(e),
                    "json_response": json_res,
                },
            )
            return []
        
    def handle_exception_response(self, json_res: Union[str, Exception]) -> str:
        try:
            if isinstance(json_res, Exception):
                json_string = str(json_res)
            else:
                json_string = json_res
        
            if isinstance(json_string, str):
                try:
                    json_data = json.loads(json_string)
                except json.JSONDecodeError:
                    # If it's not valid JSON, return the original string
                    return json_string
            else:
                json_data = json_string
        
            exception_response = ExceptionWithStatusCode.model_validate(json_data)
            error_message: str = error_mapper.get_string_error(exception_response.statusCode)
        
            if error_message is not None:
                return error_message
            else:
                return json_string
            
        except Exception as e:
            # Fallback: return the original input as string
            return str(json_res)
        
