import asyncio
import logging
from typing import Optional
from types import SimpleNamespace
import websockets

logger = logging.getLogger(__name__)


class WebSocketClient:
    def __init__(self, uri: str, websocket_callback):
        """Initialize the WebSocket client with a target URI."""
        self.uri = uri
        self.websocket = None
        self.running = False
        self.receive_task: Optional[asyncio.Task] = None
        self.websocket_callback = websocket_callback

    async def connect(self):
        """Establish a connection to the WebSocket server."""
        try:
            self.websocket = await websockets.connect(self.uri)
            self.running = True
            logger.info("Connected to %s", self.uri)
            # Start receiving messages in the background
            self.receive_task = asyncio.create_task(self.receive_loop())

            self.websocket_callback.onopen()

        except websockets.InvalidURI:
            logger.error("Invalid URI: %s", self.uri)
            raise
        except websockets.InvalidHandshake:
            logger.error("Handshake failed with %s", self.uri)
            raise
        except ConnectionRefusedError:
            logger.error("Connection refused by %s", self.uri)
            raise
        except Exception as e:
            logger.error("Unexpected error connecting to %s: %s}", self.uri, e)
            raise

    async def disconnect(self):
        """Close the WebSocket connection."""
        if self.websocket and self.running:
            try:
                if self.receive_task:
                    self.receive_task.cancel()
                    await self.receive_task
                await self.websocket.close()
                self.running = False
                logger.info("Disconnected from %s", self.uri)
            except Exception as e:
                logger.error("Error during disconnect: %s", e)
            finally:
                self.websocket = None
                self.receive_task = None
        # TODO: more error code?
        self.websocket_callback.onclose()

    async def send(self, message: str):
        if not self.running or not self.websocket:
            logger.error("Cannot send: Client is not connected")
            raise RuntimeError("Client is not connected")

        try:
            byte_data = bytes.fromhex(message)
            await self.websocket.send(byte_data)
        except websockets.ConnectionClosed:
            logger.error("Connection closed while sending")
            self.running = False
            raise
        except Exception as e:
            logger.error("Error sending message: %s", e)
            raise

    async def receive_loop(self):
        """Continuously receive messages from the server."""
        if not self.websocket:
            logger.error("Cannot receive: No active connection")
            return

        try:
            while self.running:
                message = await self.websocket.recv()
                await self.process_message(message)
        except websockets.ConnectionClosedOK:
            logger.info("Connection closed gracefully by server")
        except websockets.ConnectionClosedError as e:
            logger.error("Connection error: %s", e)
        except Exception as e:
            logger.error("Unexpected error in receive loop: %s", e)
        finally:
            self.running = False

    async def process_message(self, message: str | bytes):
        """Process received messages (customize as needed)."""
        try:
            if isinstance(message, str):
                data = message.encode("utf-8").hex()
            elif isinstance(message, bytes):
                data = message.hex()
            else:
                raise TypeError("Only support str or bytes")
            self.websocket_callback.onmessage(data)

        except Exception as e:
            logger.error("Error processing message: %s", e)

    async def run(self):
        """Run the client with a sample interaction."""
        try:
            await self.connect()

            # Keep running until interrupted or connection closes
            while self.running:
                await asyncio.sleep(1)

        except Exception as e:
            logger.error("Run error: %s", e)
        finally:
            await self.disconnect()


class WebSocketClientManager:
    def __init__(self):
        self.__curr_id = 0
        self.__ws_clients: dict[int:WebSocketClient] = {}
        self.__ws_tasks: dict[int : asyncio.Task] = {}

    def create_ws_client(self, url: str, onopen, onmessage, onclose):
        ws_callback = SimpleNamespace(
            onopen=onopen, onmessage=onmessage, onclose=onclose
        )
        ws_client = WebSocketClient(url, ws_callback)
        ws_task = asyncio.create_task(ws_client.run())
        self.__curr_id += 1
        ws_id = self.__curr_id

        self.__ws_clients[ws_id] = ws_client
        self.__ws_tasks[ws_id] = ws_task
        return ws_id

    def cancel_ws(self, ws_id: int) -> None:
        task = self.__ws_tasks[ws_id]
        task.cancel()
        del self.__ws_tasks[ws_id]

    async def send_msg(self, ws_id: int, msg: str) -> None:
        await self.__ws_clients[ws_id].send(msg)
